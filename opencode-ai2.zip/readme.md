<div align="center" style="padding: 14px 10%;">
  <img src="asset/opencode-wordmark-dark.png" alt="OpenCode wordmark" width="100%"/>
</div>

<div align="center">

![Version](https://img.shields.io/badge/version-1.1.7-blue.svg)
![License](https://img.shields.io/badge/license-MIT-green.svg)
![Acode](https://img.shields.io/badge/Acode-Compatible-orange.svg)

</div>

**Run the OpenCode AI coding agent inside Acode Editor**

[Features](#features) • [Requirements](#requirements) • [Installation](#installation) • [Troubleshooting](#troubleshooting) • [Contributing](#contributing)

**OpenCode AI** is an Acode plugin that launches [OpenCode](https://github.com/anomalyco/opencode) — an AI coding agent — as a background HTTP server inside Acode's built-in Alpine Linux terminal, then embeds its web UI in a full-page iframe. Instead of running OpenCode on a separate machine, this plugin runs it locally on your device and talks to it over loopback, giving you a fully self-contained AI coding workflow inside Acode.

## Requirements

**Node.js and npm** must be available in Acode's built-in Alpine Linux terminal, and OpenCode is installed automatically on first launch. Acode must be a recent version with Terminal and Executor API support:

```bash
apk add --no-cache nodejs npm
```

## Features

- **Local OpenCode server.** Runs OpenCode as a background HTTP server inside Acode's Alpine terminal — no external machine required.
- **Automatic install.** Detects whether OpenCode is present and installs it on demand (`npm install -g opencode-ai`).
- **V2 ready with automatic sign-in.** V2 servers start password-protected and the embedded UI signs in on its own; V1 installs keep working, and updating migrates V1 → V2.
- **Loopback port.** Serves on `127.0.0.1:4096` for the embedded web UI.

## Installation

### From the Plugins list

1. Open **Settings**
2. Select **Plugins**
3. Search for **"OpenCode AI"**
4. Tap **Install**
5. Restart Acode

### From a URL

1. Open **Settings** → **Plugins**
2. Tap **+** (top right) and choose **REMOTE**
3. Paste this URL and confirm:

```
https://raw.githubusercontent.com/MrJeffAgency/opencode-ai/main/opencode-ai.zip
```

4. Restart Acode

### Usage

Tap the **OpenCode** icon. The plugin checks for OpenCode, installs it if missing, starts the server and opens the web UI. The first launch can take a few minutes while it downloads.

## Troubleshooting

If the automatic install fails, run the commands yourself in Acode's terminal, then tap the OpenCode icon again:

```bash
apk add --no-cache nodejs npm libgcc libstdc++ ripgrep git
npm install -g opencode-ai
opencode serve --port 4096 --hostname 127.0.0.1
```

- Type the hostname exactly as `127.0.0.1`, with no trailing dot.
- **`opencode: not installed`**: the install was interrupted. Run `npm uninstall -g opencode-ai`, then `npm install -g opencode-ai`.
- **`Database is not empty and has no session table`**: move the broken database aside with `mkdir -p ~/oc-backup && mv ~/.local/share/opencode/opencode.db* ~/oc-backup/`, then start again.
- **Server won't stop or port 4096 is busy**: run `pkill -f "opencode serve"`.
- `proot warning: can't sanitize binding` lines in the terminal are harmless.

### How It Works

The plugin follows a **Check → Install → Serve → Render** workflow:

| Stage               | Responsibility                                                            |
| ------------------- | ------------------------------------------------------------------------- |
| **Check**           | Verify OpenCode is installed and whether the server is already running    |
| **Install**         | Install OpenCode via `npm install -g opencode-ai` if missing             |
| **Serve**           | Start `opencode serve --port 4096 --hostname 127.0.0.1` in the background |
| **Render**          | Embed the web UI in an iframe and reactively reflect the current state    |

## Project Structure

```
src/
  main.ts               # plugin init/destroy, flow orchestration
  types.ts              # AppState enum, StateContext, ErrorInfo
  state.ts              # state machine (transition, onStateChange, reset)
  logger.ts             # leveled logging (createLogger, setLogLevel)
  error.ts              # extractErrorInfo() — normalizes unknown errors
  config/               # named constants, split by domain
  terminal/executor.ts  # thin wrapper over global Executor
  opencode/
    install.ts          # checkInstalled, installOpenCode
    server.ts           # startServer, stopServer, restartServer
    auth.ts             # per-launch password, auth_token iframe sign-in
    update.ts           # checkForUpdates, installUpdate
    health.ts           # loopback health probe via cordova.plugin.http
  ui/
    index.ts            # render orchestrator, one render func per state
    components/         # DOM factory functions, one file per component
```

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request and leave a ⭐

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request and leave a ⭐

## Credits & Attribution

This project (the Acode OpenCode integration) is licensed under the MIT License. See the `LICENSE` file.

- OpenCode — https://github.com/anomalyco/opencode  
  Licensed under the MIT License.

## Support & Contact

- **GitHub**: [MrJeffAgency](https://github.com/MrJeffAgency)

---

<div align="center">

_Happy coding ✨_

</div>
