# Local Web View

Live HTML preview and one-tap script runner for Acode.
Version **1.4.0** · by MrJeffAgency

## How to use

1. Install the plugin, then restart Acode. You will see a "Local Web View loaded" message and a green **Local Web** tab on the right edge of the screen (next to your other plugin tabs). Press and drag the tab up or down to move it; it remembers where you leave it.
2. Open a file and tap the Local Web tab:
   - **HTML / SVG** opens the preview panel. It refreshes while you type and loads your relative CSS and JS files.
   - **.py** runs in the Acode terminal with `python3`.
   - **.cjs / .mjs** runs in the Acode terminal with `node`.
   - Anything else opens the panel with a short "nothing to preview" note.
3. You can also run **Local Web View: Open preview** from the command palette (or press Ctrl-Alt-P).

## Preview panel buttons

| Button | What it does |
|---|---|
| ✕ | Close the panel |
| ⟳ | Reload |
| ☆ | Bookmark the URL in the URL box |
| 🔖 | Open your bookmarks (tap to open, ✎ rename, 🗑 delete) |
| URL box + Go | Open a URL. Type a port (`3000`), a path (`/admin`) or a full URL. Empty box = current file |
| 🖥 | Open your saved host and port |
| ⚙ | Settings (host and default port) |
| 📱 | Switch between full width and phone width |
| 🐞 | Show or hide the console (log, warn, error) |

## Settings

Tap ⚙ to set your **host** (for example `localhost` or `192.168.1.5`) and **default port**. They are saved on your phone.
The URL box, the 🖥 button and short entries like `3000` or `/admin` all use them.

## Running scripts

- Python needs `python3` in the Acode terminal, and Node scripts need `node`. If one is missing, the terminal tells you how to install it.
- Output ends with `[exit code N]`, so you can tell a quiet success (0) from a failure.
- Files in the Acode terminal's public folder and in normal phone storage can be run. Files from other folders may not have a terminal path; the message shows the path it saw.

## Install from GitHub (Remote)

Settings → Plugins → + → REMOTE, then paste:

https://raw.githubusercontent.com/MrJeffAgency/Plugins/main/local-web-view.zip

The same link is in the plugin's ⚙ settings with a Copy button.

## Updating

Install the new zip over the old one, or use the GitHub (Remote) link above again (uninstall first if Acode shows two copies).
The version number is shown at the bottom of the ⚙ settings box.

## Changelog

- **1.4.0**: GitHub (Remote) install link in the readme and in ⚙ settings with a Copy button
- **1.3.1**: Fix running .py/.cjs/.mjs (opens a real shell terminal, brings it to the front, supports files in the Acode terminal public folder)
- **1.3.0**: Bookmarks (☆ and 🔖), floating 🌐 replaced by a draggable "Local Web" side tab, two-row toolbar
- **1.2.0**: Settings button (host and default port), 🖥 button, short URL entries, version shown in settings
- **1.1.1**: Run `.cjs` and `.mjs` with node, run diagnostics (command check and exit code)
- **1.1.0**: Run `.py` in the Acode terminal, author set to MrJeffAgency
- **1.0.1**: Floating 🌐 button, own full-screen panel
- **1.0.0**: First version: HTML preview, console, phone width
