# Changelog

- **1.4.0**: GitHub (Remote) install link in the readme and in settings, with a Copy button
- **1.3.1**: Fix running .py/.cjs/.mjs (real shell terminal, brings it to the front, supports the terminal public folder)
- **1.3.0**: Bookmarks, draggable "Local Web" side tab replaces the 🌐 button, two-row toolbar
- **1.2.0**: Settings (host and default port), 🖥 button, short URL entries, version shown in settings
- **1.1.1**: Run .cjs and .mjs with node, run diagnostics (command check and exit code)
- **1.1.0**: Run .py files in the Acode terminal
- **1.0.1**: Floating 🌐 button, full-screen preview panel
- **1.0.0**: First release: HTML preview, console, phone width
