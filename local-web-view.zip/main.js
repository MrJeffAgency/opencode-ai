(function () {
  const ID = 'mrjeffagency.localwebview';
  const VERSION = '1.4.0';
  const REMOTE = 'https://raw.githubusercontent.com/MrJeffAgency/Plugins/main/local-web-view.zip';
  const KEY = 'lwv.settings';
  const defaults = { host: 'localhost', port: '8080', tabTop: 455 };
  const MKEY = 'lwv.bookmarks';
  const loadMarks = () => { try { return JSON.parse(localStorage.getItem(MKEY) || '[]'); } catch (e) { return []; } };
  const saveMarks = (v) => { try { localStorage.setItem(MKEY, JSON.stringify(v)); } catch (e) {} };
  const loadSettings = () => {
    try { return Object.assign({}, defaults, JSON.parse(localStorage.getItem(KEY) || '{}')); }
    catch (e) { return Object.assign({}, defaults); }
  };
  const saveSettings = (v) => { try { localStorage.setItem(KEY, JSON.stringify(v)); } catch (e) {} };

  class LocalWebView {
    constructor() {
      this.page = null;
      this.iframe = null;
      this.mode = 'file'; // 'file' | 'url'
      this.timer = null;
      this.consoleOpen = false;
      this.onMsg = this.onMsg.bind(this);
      this.onChange = this.onChange.bind(this);
    }

    async init() {
      const say = (m) => { try { window.toast(m, 3000); } catch (e) {} };
      try {
        editorManager.editor.commands.addCommand({
          name: 'local-web-view',
          description: 'Local Web View: Open preview',
          bindKey: { win: 'Ctrl-Alt-P', mac: 'Command-Alt-P' },
          exec: () => this.launch(),
        });
      } catch (e) {}
      // side tab on the right edge, like the other plugin tabs
      const fab = document.createElement('div');
      fab.textContent = 'Local Web';
      const top0 = Math.min(Math.max(Number(loadSettings().tabTop) || 455, 60), window.innerHeight - 140);
      fab.style.cssText = 'position:fixed;right:0;top:' + top0 + 'px;writing-mode:vertical-rl;padding:12px 6px;background:#a5d6a7;color:#111;font-size:15px;font-weight:500;z-index:9998;border-radius:6px 0 0 6px;box-shadow:-1px 1px 6px rgba(0,0,0,.4);touch-action:none;user-select:none';
      let startY = 0, startTop = 0, moved = false;
      fab.addEventListener('touchstart', (e) => {
        startY = e.touches[0].clientY; startTop = fab.offsetTop; moved = false;
      }, { passive: true });
      fab.addEventListener('touchmove', (e) => {
        const dy = e.touches[0].clientY - startY;
        if (Math.abs(dy) > 10) moved = true;
        if (moved) {
          const t = Math.min(Math.max(startTop + dy, 60), window.innerHeight - fab.offsetHeight - 20);
          fab.style.top = t + 'px';
        }
      }, { passive: true });
      fab.addEventListener('touchend', () => {
        if (moved) saveSettings(Object.assign(loadSettings(), { tabTop: fab.offsetTop }));
      });
      fab.onclick = () => { if (moved) { moved = false; return; } this.launch(); };
      document.body.appendChild(fab);
      this.fab = fab;
      window.addEventListener('message', this.onMsg);
      say('Local Web View loaded');
    }

    async destroy() {
      try { editorManager.editor.commands.removeCommand('local-web-view'); } catch (e) {}
      window.removeEventListener('message', this.onMsg);
      if (this.fab) this.fab.remove();
      this.close();
    }

    close() {
      try { editorManager.editor.off('change', this.onChange); } catch (e) {}
      if (this.root) this.root.remove();
      this.root = null; this.iframe = null;
    }

    open() {
      try {
        if (this.root) this.close();
        const root = document.createElement('div');
        root.style.cssText = 'position:fixed;inset:0;z-index:9999;display:flex;flex-direction:column;background:#222;color:#eee;font-family:sans-serif';
        root.innerHTML = `
          <div style="display:flex;flex-direction:column;gap:6px;padding:6px;background:#1e88e5">
            <div style="display:flex;gap:6px;align-items:center">
              <button data-a="close" style="padding:6px 10px">✕</button>
              <button data-a="reload" style="padding:6px 10px">⟳</button>
              <input data-a="url" placeholder="port, path or URL"
                style="flex:1;min-width:0;padding:6px;border-radius:6px;border:0">
              <button data-a="go" style="padding:6px 10px">Go</button>
            </div>
            <div style="display:flex;gap:6px;justify-content:space-between">
              <button data-a="mark" style="flex:1;padding:6px">☆</button>
              <button data-a="marks" style="flex:1;padding:6px">🔖</button>
              <button data-a="host" style="flex:1;padding:6px">🖥</button>
              <button data-a="size" style="flex:1;padding:6px">📱</button>
              <button data-a="console" style="flex:1;padding:6px">🐞</button>
              <button data-a="settings" style="flex:1;padding:6px">⚙</button>
            </div>
          </div>
          <div data-a="wrap" style="flex:1;display:flex;justify-content:center;overflow:auto;min-height:0">
            <iframe data-a="frame" style="border:0;background:#fff;width:100%;height:100%"
              sandbox="allow-scripts allow-forms allow-modals allow-popups allow-same-origin"></iframe>
          </div>
          <pre data-a="log" style="display:none;margin:0;max-height:35%;overflow:auto;padding:6px;font-size:12px;background:#111;color:#ddd;white-space:pre-wrap"></pre>`;
        const q = (n) => root.querySelector(`[data-a="${n}"]`);
        this.root = root;
        this.iframe = q('frame');
        this.urlInput = q('url');
        this.logEl = q('log');
        this.phone = false;
        this.mode = 'file';
        q('close').onclick = () => this.close();
        q('reload').onclick = () => this.render();
        q('go').onclick = () => this.go();
        q('host').onclick = () => { this.urlInput.value = this.baseUrl(); this.go(); };
        q('settings').onclick = () => this.showSettings();
        q('mark').onclick = () => this.addBookmark();
        q('marks').onclick = () => this.showBookmarks();
        this.urlInput.placeholder = this.baseUrl() + ' (empty = current file)';
        this.urlInput.onkeydown = (e) => { if (e.key === 'Enter') this.go(); };
        q('size').onclick = () => {
          this.phone = !this.phone;
          this.iframe.style.width = this.phone ? '390px' : '100%';
        };
        q('console').onclick = () => {
          this.consoleOpen = !this.consoleOpen;
          this.logEl.style.display = this.consoleOpen ? 'block' : 'none';
        };
        document.body.appendChild(root);
        editorManager.editor.on('change', this.onChange);
        this.render();
      } catch (e) {
        try { window.toast('Local Web View error: ' + e.message, 5000); } catch (_) { alert(e.message); }
      }
    }

    toast(m, t) { try { window.toast(m, t || 3000); } catch (e) {} }

    launch() {
      const f = editorManager.activeFile;
      const name = (f && f.name) || '';
      if (/\.(py|cjs|mjs)$/i.test(name)) return this.runPython(f);
      this.open();
    }

    termPath(uri) {
      try {
        const ax = acode.require('acodex');
        if (ax && ax.getPath) { const p = ax.getPath(uri); if (p) return p; }
      } catch (e) {}
      if (!uri) return null;
      if (uri.startsWith('file://')) return decodeURIComponent(uri.slice(7));
      if (uri.startsWith('content://')) {
        let d = uri;
        try { d = decodeURIComponent(decodeURIComponent(uri)); } catch (e) { try { d = decodeURIComponent(uri); } catch (_) {} }
        // Acode terminal "public" folder (files inside the app's private storage)
        const m = d.match(/(\/data\/user\/0\/com\.foxdebug\.acode\/files\/[^:]*)$/) || d.match(/(\/data\/user\/0\/com\.foxdebug\.acode\/files\/.*)/);
        if (m) return m[1];
        // normal phone storage picked through the system file picker
        const p = d.match(/primary:([^:]*)$/);
        if (p) return '/sdcard/' + p[1];
      }
      return null;
    }

    async runPython(file) {
      try { if (file.isUnsaved) acode.exec('save'); } catch (e) {}
      await new Promise((r) => setTimeout(r, 300));
      const path = this.termPath(file.uri);
      if (!path) {
        this.toast('Cannot find a terminal path for: ' + String(file.uri).slice(0, 140), 8000);
        return;
      }
      const q = (x) => `'${x.replace(/'/g, `'\\''`)}'`;
      const dir = path.replace(/\/[^/]*$/, '') || '/';
      const isPy = /\.py$/i.test(path);
      const bin = isPy ? 'python3' : 'node';
      const run = isPy ? `python3 -u ${q(path)}` : `node ${q(path)}`;
      const hint = isPy ? 'apk add python3' : 'apk add nodejs npm';
      const base = path.split('/').pop();
      const cmd = `cd ${q(dir)}; clear; command -v ${bin} >/dev/null || echo "${bin} not installed. Try: ${hint}"; echo "> ${bin} ${base}"; ${run}; echo "[exit code $?]"`;

      // 1) AcodeX plugin (if installed)
      try {
        const ax = acode.require('acodex');
        if (ax && ax.execute) {
          if (ax.isTerminalOpened && !ax.isTerminalOpened() && ax.openTerminal) await ax.openTerminal();
          ax.execute(cmd);
          this.toast('Running ' + file.name);
          return;
        }
      } catch (e) {}

      // 2) Acode built-in terminal (needs a real shell, so createServer, not createLocal)
      try {
        const term = acode.require('terminal');
        if (term) {
          const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
          const findShell = () => {
            let found = null;
            try {
              for (const [k, v] of term.getAll()) {
                if (v && v.name === 'Local Web View') continue; // old shell-less tab
                found = { id: (v && v.id) || k, inst: v };
              }
            } catch (e) {}
            return found;
          };
          let shell = findShell();
          let fresh = false;
          if (!shell) {
            fresh = true;
            try {
              if (term.createServer) await term.createServer({ name: 'Local Web View Run' });
              else await term.create({ name: 'Local Web View Run' });
            } catch (e) {
              try { acode.exec('new-terminal'); } catch (_) {}
            }
            await sleep(500);
            shell = findShell();
          }
          if (shell && term.write) {
            // bring the terminal tab to the front
            try { if (shell.inst && shell.inst.file && shell.inst.file.makeActive) shell.inst.file.makeActive(); } catch (e) {}
            try { editorManager.switchFile(shell.id); } catch (e) {}
            if (fresh) await sleep(2500);
            term.write(shell.id, cmd + '\r');
            this.toast('Running ' + file.name);
            return;
          }
        }
      } catch (e) {
        this.toast('Terminal error: ' + e.message, 5000);
      }

      // 3) fallback: copy the command
      try { await navigator.clipboard.writeText(cmd); } catch (e) {}
      this.toast('Could not reach the terminal. Command copied: paste it into your terminal.', 6000);
    }

    baseUrl() {
      const st = loadSettings();
      return `http://${st.host}:${st.port}`;
    }

    resolveUrl(v) {
      const st = loadSettings();
      v = v.trim();
      if (/^https?:\/\//i.test(v)) return v;
      if (/^\d{2,5}$/.test(v)) return `http://${st.host}:${v}`;
      if (/^:\d+/.test(v)) return `http://${st.host}${v}`;
      if (v.startsWith('/')) return this.baseUrl() + v;
      return 'http://' + v;
    }

    showSettings() {
      const st = loadSettings();
      const box = document.createElement('div');
      box.style.cssText = 'position:absolute;inset:0;z-index:2;background:rgba(0,0,0,.6);display:flex;align-items:center;justify-content:center';
      box.innerHTML = `
        <div style="background:#333;padding:16px;border-radius:10px;width:min(340px,90%);display:flex;flex-direction:column;gap:8px">
          <b>Local Web View settings</b>
          <label>Host<input data-s="host" value="${st.host}" placeholder="localhost or 192.168.1.5" style="width:100%;padding:6px;margin-top:4px;border-radius:6px;border:0;box-sizing:border-box"></label>
          <label>Default port<input data-s="port" value="${st.port}" inputmode="numeric" style="width:100%;padding:6px;margin-top:4px;border-radius:6px;border:0;box-sizing:border-box"></label>
          <small style="opacity:.7">Tip: type just a port (3000) or a path (/admin) in the URL bar and it uses this host.</small>
          <div style="display:flex;gap:8px;justify-content:flex-end">
            <button data-s="cancel" style="padding:6px 12px">Cancel</button>
            <button data-s="save" style="padding:6px 12px">Save</button>
          </div>
          <div style="border-top:1px solid #555;padding-top:8px;display:flex;flex-direction:column;gap:6px">
            <b>Install / update from GitHub</b>
            <small style="opacity:.7">Acode → Settings → Plugins → + → REMOTE, then paste:</small>
            <input data-s="remote" readonly value="${REMOTE}" style="width:100%;padding:6px;border-radius:6px;border:0;box-sizing:border-box;font-size:11px">
            <button data-s="copy" style="padding:6px 12px">Copy link</button>
          </div>
          <small style="opacity:.6">Local Web View v${VERSION}</small>
        </div>`;
      const g = (n) => box.querySelector(`[data-s="${n}"]`);
      g('cancel').onclick = () => box.remove();
      g('copy').onclick = async () => {
        let ok = false;
        try { await navigator.clipboard.writeText(REMOTE); ok = true; } catch (e) {}
        if (!ok) { try { cordova.plugins.clipboard.copy(REMOTE); ok = true; } catch (e) {} }
        if (!ok) { try { g('remote').select(); ok = document.execCommand('copy'); } catch (e) {} }
        this.toast(ok ? 'Link copied' : 'Press and hold the link to copy it');
      };
      g('save').onclick = () => {
        let host = g('host').value.trim().replace(/^https?:\/\//i, '').replace(/\/.*$/, '').replace(/:\d+$/, '');
        const port = g('port').value.trim().replace(/\D/g, '');
        saveSettings(Object.assign(loadSettings(), { host: host || defaults.host, port: port || defaults.port }));
        this.urlInput.placeholder = this.baseUrl() + ' (empty = current file)';
        box.remove();
        this.toast('Saved: ' + this.baseUrl());
      };
      this.root.appendChild(box);
    }

    addBookmark() {
      const v = this.urlInput.value.trim();
      if (!v) return this.toast('Type a URL first, then tap ☆');
      const url = this.resolveUrl(v);
      const list = loadMarks();
      if (list.some((x) => x.url === url)) return this.toast('Already bookmarked');
      list.push({ name: url.replace(/^https?:\/\//i, ''), url });
      saveMarks(list);
      this.toast('Bookmarked: ' + url);
    }

    showBookmarks() {
      const box = document.createElement('div');
      box.style.cssText = 'position:absolute;inset:0;z-index:2;background:rgba(0,0,0,.6);display:flex;align-items:center;justify-content:center';
      const card = document.createElement('div');
      card.style.cssText = 'background:#333;padding:14px;border-radius:10px;width:min(360px,92%);max-height:75%;display:flex;flex-direction:column;gap:8px';
      const head = document.createElement('div');
      head.style.cssText = 'display:flex;justify-content:space-between;align-items:center';
      head.innerHTML = '<b>Bookmarks</b>';
      const x = document.createElement('button');
      x.textContent = '✕'; x.style.padding = '4px 10px'; x.onclick = () => box.remove();
      head.appendChild(x);
      const listEl = document.createElement('div');
      listEl.style.cssText = 'overflow:auto;display:flex;flex-direction:column;gap:6px';
      const draw = () => {
        listEl.innerHTML = '';
        const list = loadMarks();
        if (!list.length) { listEl.textContent = 'No bookmarks yet. Type a URL and tap ☆.'; return; }
        list.forEach((b, i) => {
          const row = document.createElement('div');
          row.style.cssText = 'display:flex;gap:6px;align-items:center';
          const open = document.createElement('button');
          open.textContent = b.name;
          open.style.cssText = 'flex:1;text-align:left;padding:8px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap';
          open.onclick = () => { this.urlInput.value = b.url; this.mode = 'url'; box.remove(); this.render(); };
          const ren = document.createElement('button');
          ren.textContent = '✎'; ren.style.padding = '8px';
          ren.onclick = () => {
            const n = prompt('Bookmark name', b.name);
            if (n && n.trim()) { const l = loadMarks(); l[i].name = n.trim(); saveMarks(l); draw(); }
          };
          const del = document.createElement('button');
          del.textContent = '🗑'; del.style.padding = '8px';
          del.onclick = () => { const l = loadMarks(); l.splice(i, 1); saveMarks(l); draw(); };
          row.append(open, ren, del);
          listEl.appendChild(row);
        });
      };
      draw();
      card.append(head, listEl);
      box.appendChild(card);
      this.root.appendChild(box);
    }

    go() {
      const v = this.urlInput.value.trim();
      this.mode = v ? 'url' : 'file';
      this.render();
    }

    onChange() {
      if (this.mode !== 'file') return;
      clearTimeout(this.timer);
      this.timer = setTimeout(() => this.render(), 500);
    }

    onMsg(e) {
      const d = e.data;
      if (!d || d.__lwv !== true || !this.logEl) return;
      const line = document.createElement('div');
      line.style.color = d.level === 'error' ? '#ff6b6b' : d.level === 'warn' ? '#ffd166' : '#ddd';
      line.textContent = `[${d.level}] ${d.text}`;
      this.logEl.appendChild(line);
      this.logEl.scrollTop = this.logEl.scrollHeight;
    }

    async render() {
      if (!this.iframe) return;
      this.logEl.innerHTML = '';
      if (this.mode === 'url') {
        const u = this.resolveUrl(this.urlInput.value);
        this.iframe.removeAttribute('srcdoc');
        this.iframe.src = u;
        return;
      }
      const file = editorManager.activeFile;
      let html = editorManager.editor.getValue();
      if (file && !/\.(html?|svg|xhtml)$/i.test(file.name || '')) {
        html = `<!doctype html><html><body style="font-family:sans-serif;padding:16px"><h3>Nothing to preview</h3><p>"${(file.name||'this file').replace(/</g,'&lt;')}" is not an HTML file. Open an .html file, or type a localhost URL above and tap Go.</p></body></html>`;
      }
      html = await this.inline(html, file);
      html = this.inject(html);
      this.iframe.removeAttribute('src');
      this.iframe.srcdoc = html;
    }

    async readRel(path, file) {
      try {
        if (!file || !file.uri || /^(https?:)?\/\//i.test(path) || path.startsWith('data:')) return null;
        const Url = acode.require('url');
        const fsOp = acode.require('fsOperation');
        const base = Url.dirname(file.uri);
        const full = Url.join(base, path.split('?')[0]);
        return await fsOp(full).readFile('utf8');
      } catch (e) { return null; }
    }

    async inline(html, file) {
      const css = [...html.matchAll(/<link[^>]+rel=["']?stylesheet["']?[^>]*>/gi)];
      for (const m of css) {
        const href = (m[0].match(/href=["']([^"']+)["']/i) || [])[1];
        if (!href) continue;
        const txt = await this.readRel(href, file);
        if (txt != null) html = html.replace(m[0], `<style>${txt}</style>`);
      }
      const js = [...html.matchAll(/<script[^>]+src=["']([^"']+)["'][^>]*>\s*<\/script>/gi)];
      for (const m of js) {
        const txt = await this.readRel(m[1], file);
        if (txt != null) html = html.replace(m[0], () => `<script>${txt.replace(/<\/script/gi, '<\\/script')}<\/script>`);
      }
      return html;
    }

    inject(html) {
      const s = `<script>(function(){function send(l,a){try{parent.postMessage({__lwv:true,level:l,text:[].map.call(a,function(x){try{return typeof x==='object'?JSON.stringify(x):String(x)}catch(e){return String(x)}}).join(' ')},'*')}catch(e){}}
['log','info','warn','error'].forEach(function(k){var o=console[k];console[k]=function(){send(k==='info'?'log':k,arguments);o.apply(console,arguments)}});
window.addEventListener('error',function(e){send('error',[e.message+' ('+(e.lineno||0)+':'+(e.colno||0)+')'])});
window.addEventListener('unhandledrejection',function(e){send('error',['Unhandled: '+e.reason])});})();<\/script>`;
      return /<head[^>]*>/i.test(html) ? html.replace(/<head[^>]*>/i, (m) => m + s) : s + html;
    }
  }

  if (window.acode) {
    const p = new LocalWebView();
    acode.setPluginInit(ID, async () => { await p.init(); });
    acode.setPluginUnmount(ID, () => p.destroy());
  }
})();
