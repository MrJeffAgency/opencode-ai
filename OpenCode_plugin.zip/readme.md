# OpenCode AI for Acode

Runs the [OpenCode](https://opencode.ai) AI coding agent locally inside Acode's built-in Alpine terminal and embeds its web UI in a full-page view.

## Requirements
Recent Acode with Terminal + Executor API, and the built-in terminal set up (Menu → Terminal).
Missing dependencies and OpenCode are installed automatically on first launch.

## Usage
Command palette (Ctrl+Shift+P):
- **OpenCode: Open** – check → install → serve → render
- **OpenCode: Set project folder** – Alpine path the agent works in
- **OpenCode: Stop server**

## Manual install (if auto-install fails)
```
apk add --no-cache nodejs npm git libgcc libstdc++ gcompat ripgrep
npm install -g opencode-ai
opencode web --port 4096 --hostname 127.0.0.1
```
Server listens on 127.0.0.1:4096 (loopback only).
