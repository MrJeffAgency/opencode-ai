/* OpenCode AI for Acode  —  Check → Install → Serve → Render */
(function () {
  const ID = "mrjeffagency.opencode";
  const HOST = "127.0.0.1";
  const PORT = 4096;
  const URL_ = `http://${HOST}:${PORT}/`;
  const LOG = "/tmp/opencode.log";
  const KEY = ID + ".workdir";

  const S = { IDLE: "idle", CHECK: "checking", INSTALL: "installing", SERVE: "starting", READY: "ready", ERROR: "error" };

  let page = null, state = S.IDLE, busy = false, logLines = [], errMsg = "";

  /* ---------- terminal (Alpine) ---------- */
  const sh = (cmd) => Executor.execute(cmd, true);

  /* ---------- opencode ---------- */
  const isInstalled = async () => {
    try { return (await sh("command -v opencode && echo yes")).includes("yes"); } catch { return false; }
  };
  const isRunning = async () => {
    try {
      const c = new AbortController();
      const t = setTimeout(() => c.abort(), 1500);
      await fetch(URL_, { mode: "no-cors", signal: c.signal });
      clearTimeout(t);
      return true;
    } catch { return false; }
  };
  const install = async () => {
    log("Installing Node.js, npm and tools…");
    await sh("apk add --no-cache nodejs npm git libgcc libstdc++ gcompat ripgrep 2>&1");
    log("Installing OpenCode (npm install -g opencode-ai)… this can take a few minutes");
    await sh("npm install -g opencode-ai 2>&1");
    // "No such file or directory" on a present binary = glibc build on Alpine; verify it actually runs
    let ok = false;
    try { ok = (await sh("opencode --version 2>&1 && echo OCOK")).includes("OCOK"); } catch {}
    if (!ok) {
      log("Binary won't run (glibc build on Alpine). Trying musl build…");
      const arch = (await sh("uname -m")).trim() === "x86_64" ? "x64" : "arm64";
      await sh(`npm install -g opencode-linux-${arch}-musl 2>&1`);
      const root = (await sh("npm root -g")).trim();
      await sh(`B=${root}/opencode-linux-${arch}-musl/bin/opencode; [ -f "$B" ] && ln -sf "$B" /usr/local/bin/opencode; echo done`);
      try { ok = (await sh("opencode --version 2>&1 && echo OCOK")).includes("OCOK"); } catch {}
    }
    if (!ok) throw new Error("OpenCode installed but won't run. Try: apk add gcompat libstdc++ libgcc");
    log("OpenCode installed ✔");
  };
  const workdir = () => localStorage.getItem(KEY) || "$HOME";
  const startServer = async () => {
    const cmd =
      `cd "${workdir()}" 2>/dev/null || cd "$HOME"; ` +
      `(setsid nohup opencode web --port ${PORT} --hostname ${HOST} > ${LOG} 2>&1 < /dev/null &) ; echo ok`;
    await sh(cmd);
    for (let i = 0; i < 40; i++) {            // wait up to ~20s
      if (await isRunning()) return;
      await new Promise((r) => setTimeout(r, 500));
    }
    let tail = "";
    try { tail = await sh(`tail -n 15 ${LOG}`); } catch {}
    throw new Error("Server did not start.\n" + tail);
  };
  const stopServer = async () => {
    try { await sh(`pkill -f "opencode.*--port ${PORT}" ; echo done`); } catch {}
  };

  /* ---------- state + UI ---------- */
  const log = (m) => { logLines.push(m); if (logLines.length > 60) logLines.shift(); render(); };
  const set = (s) => { state = s; render(); };

  const el = (tag, css, html) => {
    const e = document.createElement(tag);
    if (css) e.style.cssText = css;
    if (html != null) e.innerHTML = html;
    return e;
  };
  const btn = (label, fn) => {
    const b = el("button", "margin:6px;padding:10px 18px;border:0;border-radius:8px;background:var(--primary-color,#39f);color:var(--primary-text-color,#fff);font-size:15px", label);
    b.onclick = fn;
    return b;
  };
  const esc = (s) => String(s).replace(/[&<>]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;" }[c]));

  function render() {
    if (!page) return;
    const body = page.body;
    body.innerHTML = "";
    body.style.cssText = "height:100%;display:flex;flex-direction:column;background:var(--primary-color)";

    if (state === S.READY) {
      const bar = el("div", "display:flex;justify-content:flex-end;padding:4px;flex:0 0 auto");
      bar.append(btn("Restart", () => run(true)), btn("Stop", async () => { await stopServer(); set(S.IDLE); }));
      const f = el("iframe", "flex:1;width:100%;border:0;background:#fff");
      f.src = URL_;
      f.allow = "clipboard-read; clipboard-write";
      body.append(bar, f);
      return;
    }

    const box = el("div", "margin:auto;padding:20px;text-align:center;max-width:520px;color:var(--secondary-text-color,#ccc)");
    const titles = {
      [S.IDLE]: "OpenCode AI", [S.CHECK]: "Checking OpenCode…", [S.INSTALL]: "Installing OpenCode…",
      [S.SERVE]: "Starting server…", [S.ERROR]: "Something went wrong",
    };
    box.append(el("h2", "margin:0 0 12px", titles[state] || ""));
    if (state === S.IDLE) {
      box.append(el("p", "", `Runs the OpenCode AI agent locally in Acode's Alpine terminal on ${HOST}:${PORT}.`));
      box.append(btn("Launch", () => run(false)));
    }
    if (state === S.ERROR) {
      box.append(el("pre", "text-align:left;white-space:pre-wrap;font-size:12px;max-height:40vh;overflow:auto", esc(errMsg)));
      box.append(el("p", "font-size:13px", "Manual fix in the Acode terminal:<br><code>apk add --no-cache nodejs npm git libgcc libstdc++ gcompat ripgrep<br>npm install -g opencode-ai</code>"));
      box.append(btn("Retry", () => run(false)));
    }
    if (logLines.length && state !== S.IDLE)
      box.append(el("pre", "text-align:left;white-space:pre-wrap;font-size:12px", esc(logLines.join("\n"))));
    body.append(box);
  }

  /* ---------- flow ---------- */
  async function run(forceRestart) {
    if (busy) return;
    busy = true; logLines = [];
    try {
      if (forceRestart) await stopServer();
      set(S.CHECK);
      if (!(await isInstalled())) { set(S.INSTALL); await install(); }
      if (!(await isRunning())) { set(S.SERVE); await startServer(); }
      set(S.READY);
    } catch (e) {
      errMsg = (e && (e.message || e.toString())) || "Unknown error";
      set(S.ERROR);
    } finally { busy = false; }
  }

  let hostPage = null;
  function open() {
    try {
      if (typeof Executor === "undefined") {
        acode.alert("OpenCode AI", "This plugin needs a recent Acode with Terminal & Executor API. Update Acode and set up the built-in terminal first.");
        return;
      }
      if (!hostPage) throw new Error("Plugin page not ready, restart Acode");
      try { acode.require("sidebar").hide(); } catch {}
      page = hostPage;
      if (page.settitle) page.settitle("OpenCode AI");
      else if (page.setTitle) page.setTitle("OpenCode AI");
      page.onhide = () => { page = null; };
      state = S.IDLE; render();
      page.show();
      run(false);
    } catch (e) {
      console.error("OpenCode open:", e);
      acode.alert("OpenCode AI", "Could not open: " + ((e && e.message) || e));
    }
  }

  async function setFolder() {
    const prompt = acode.require("prompt");
    const v = await prompt("Project folder (Alpine path)", workdir(), "text", { placeholder: "/home/myproject" });
    if (v) { localStorage.setItem(KEY, v); window.toast && window.toast("Saved. Use Restart to apply.", 3000); }
  }

  /* ---------- sidebar ---------- */
  const SB_ID = "opencode-ai";
  const SB_ICON = "opencode-sb-icon";
  let styleEl = null;
  function addSidebar() {
    const svg = encodeURIComponent(
      "<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24'><path d='M4 4h16v16H4z M8 8v8h8V8z' fill-rule='evenodd'/><rect x='10' y='10' width='4' height='4'/></svg>"
    );
    styleEl = document.createElement("style");
    styleEl.textContent =
      `.icon.${SB_ICON}{display:inline-block;background-color:currentColor;` +
      `-webkit-mask:url("data:image/svg+xml,${svg}") center/60% no-repeat;` +
      `mask:url("data:image/svg+xml,${svg}") center/60% no-repeat}` +
      `.icon.${SB_ICON}:before{content:none}`;
    document.head.append(styleEl);

    const sidebarApps = acode.require("sidebarApps");
    sidebarApps.add(SB_ICON, SB_ID, "OpenCode AI", (container) => {
      container.style.cssText = "padding:16px;text-align:center";
      container.innerHTML = "";
      const h = document.createElement("h3");
      h.textContent = "OpenCode AI";
      const p = document.createElement("p");
      p.style.cssText = "font-size:13px;opacity:.8";
      p.textContent = "AI coding agent running locally in Acode's terminal.";
      const mk = (t, fn) => {
        const b = document.createElement("button");
        b.textContent = t;
        b.style.cssText = "display:block;width:100%;margin:8px 0;padding:10px;border:0;border-radius:8px;background:var(--primary-color);color:var(--primary-text-color);filter:brightness(1.3)";
        b.onclick = fn;
        return b;
      };
      container.append(h, p, mk("Open OpenCode", open), mk("Set project folder", setFolder),
        mk("Stop server", async () => { await stopServer(); window.toast && window.toast("OpenCode stopped", 2000); }));
    });
  }

  /* ---------- plugin lifecycle ---------- */
  if (window.acode) {
    acode.setPluginInit(ID, async (baseUrl, $page) => {
      hostPage = $page;
      try { addSidebar(); } catch (e) { console.error("OpenCode sidebar:", e); }
      const ed = editorManager.editor;
      ed.commands.addCommand({ name: "opencode-open", description: "OpenCode: Open", exec: open });
      ed.commands.addCommand({ name: "opencode-stop", description: "OpenCode: Stop server", exec: async () => { await stopServer(); window.toast && window.toast("OpenCode stopped", 2000); } });
      ed.commands.addCommand({ name: "opencode-folder", description: "OpenCode: Set project folder", exec: setFolder });
    });
    acode.setPluginUnmount(ID, () => {
      try { acode.require("sidebarApps").remove(SB_ID); } catch {}
      if (styleEl) styleEl.remove();
      const c = editorManager.editor.commands;
      ["opencode-open", "opencode-stop", "opencode-folder"].forEach((n) => c.removeCommand(n));
      stopServer();
    });
  }
})();
