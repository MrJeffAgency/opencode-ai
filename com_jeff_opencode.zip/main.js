"use strict"

;(function () {
  var PLUGIN_ID = "com.jeff.opencode"
  var STORE_PREFIX = PLUGIN_ID + ":"
  var ICON_CLASS = "opencode-icon"

  var DEFAULTS = {
    command: "opencode",
    cwd: "~",
    args: "",
    port: "4096",
    host: "127.0.0.1",
    serveArgs: "",
  }

  function readSetting(key) {
    try {
      var raw = window.localStorage.getItem(STORE_PREFIX + key)
      if (raw === null || raw === undefined) return DEFAULTS[key]
      return JSON.parse(raw)
    } catch (error) {
      return DEFAULTS[key]
    }
  }

  function writeSetting(key, value) {
    try {
      window.localStorage.setItem(STORE_PREFIX + key, JSON.stringify(value))
    } catch (error) {
      // Settings are a convenience; ignore storage failures.
    }
  }

  function toast(message, ms) {
    try {
      if (typeof window.toast === "function") {
        window.toast(message, ms || 2600)
        return
      }
      var toastFn = acode.require("toast")
      if (typeof toastFn === "function") toastFn(message, ms || 2600)
    } catch (error) {
      // Toast is optional.
    }
  }

  function notifyError(title, message) {
    try {
      if (typeof acode.pushNotification === "function") {
        acode.pushNotification(title, message, { type: "error", autoClose: false })
        return
      }
    } catch (error) {
      // Fall through to the dialogs below.
    }
    try {
      if (typeof acode.alert === "function") {
        acode.alert(title, message)
        return
      }
    } catch (error) {
      // Fall through to window.alert.
    }
    try {
      window.alert(title + "\n\n" + message)
    } catch (error) {
      console.error("[opencode] " + title + ": " + message)
    }
  }

  function shellQuote(value) {
    return "'" + String(value).replace(/'/g, "'\\''") + "'"
  }

  function cdCommand(directory) {
    var dir = String(directory || "~").trim()
    if (!dir) dir = "~"
    if (dir === "~") return "cd ~"
    if (dir.indexOf("~/") === 0) return "cd ~/" + shellQuote(dir.slice(2))
    return "cd " + shellQuote(dir)
  }

  function delay(ms) {
    return new Promise(function (resolve) {
      setTimeout(resolve, ms)
    })
  }

  function launchCommand(mode) {
    var command = String(readSetting("command") || DEFAULTS.command).trim()
    var extra = String(readSetting("args") || "").trim()
    var directory = String(readSetting("cwd") || DEFAULTS.cwd).trim()
    if (!command) command = DEFAULTS.command

    var parts = [command]
    if (extra) parts.push(extra)
    if (mode === "continue") parts.push("--continue")

    return cdCommand(directory) + " && " + parts.join(" ")
  }


  function serverPort() {
    var n = parseInt(String(readSetting("port") || DEFAULTS.port).trim(), 10)
    return n > 0 && n < 65536 ? n : parseInt(DEFAULTS.port, 10)
  }

  function serverHost() {
    return String(readSetting("host") || DEFAULTS.host).trim() || DEFAULTS.host
  }

  // 0.0.0.0 is a bind address, not something you can browse to.
  function serverUrl() {
    var host = serverHost()
    if (host === "0.0.0.0" || host === "::") host = "127.0.0.1"
    return "http://" + host + ":" + serverPort()
  }

  function serveCommand() {
    var command = String(readSetting("command") || DEFAULTS.command).trim() || DEFAULTS.command
    var extra = String(readSetting("serveArgs") || "").trim()
    var directory = String(readSetting("cwd") || DEFAULTS.cwd).trim() || DEFAULTS.cwd
    var banner = ">>> opencode server starting. When it is ready, open " + serverUrl() + " in your browser."
    var parts = [command, "serve", "--port", String(serverPort()), "--hostname", serverHost()]
    if (extra) parts.push(extra)
    return cdCommand(directory) + " && echo " + shellQuote(banner) + " && " + parts.join(" ")
  }

  // Resolves true if something answers on the URL. no-cors avoids CORS failures;
  // only a refused/timed-out connection counts as "down".
  function probe(url, timeoutMs) {
    return new Promise(function (resolve) {
      var done = false
      var ctl = typeof AbortController !== "undefined" ? new AbortController() : null
      function finish(value) {
        if (done) return
        done = true
        clearTimeout(timer)
        resolve(value)
      }
      var timer = setTimeout(function () {
        try {
          if (ctl) ctl.abort()
        } catch (error) {
          // ignore
        }
        finish(false)
      }, timeoutMs || 1500)
      try {
        fetch(url, { mode: "no-cors", cache: "no-store", signal: ctl ? ctl.signal : undefined }).then(
          function () {
            finish(true)
          },
          function () {
            finish(false)
          },
        )
      } catch (error) {
        finish(false)
      }
    })
  }

  function openExternal(url) {
    try {
      if (window.system && typeof window.system.openInBrowser === "function") {
        window.system.openInBrowser(url)
        return true
      }
    } catch (error) {
      // fall through
    }
    try {
      window.open(url, "_system")
      return true
    } catch (error) {
      return false
    }
  }

  function copyText(text) {
    try {
      if (window.cordova && cordova.plugins && cordova.plugins.clipboard) {
        cordova.plugins.clipboard.copy(text)
        return true
      }
    } catch (error) {
      // fall through
    }
    try {
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(text)
        return true
      }
    } catch (error) {
      // ignore
    }
    return false
  }

  function pick(title, options) {
    try {
      var select = acode.require("select")
      if (typeof select === "function") return select(title, options, { textTransform: false })
    } catch (error) {
      // ignore
    }
    return Promise.resolve(null)
  }

  function OpencodePlugin() {
    this.baseUrl = ""
    this.commands = null
    this.sideButton = null
    this.serverTermId = null
    this.serveRun = 0
  }

  OpencodePlugin.prototype.init = async function () {
    try {
      this.commands = acode.require("commands")
    } catch (error) {
      this.commands = null
    }
    this.registerIcon()
    this.registerCommands()
    this.registerServerCommands()
    this.registerSideButton()
  }

  OpencodePlugin.prototype.registerIcon = function () {
    try {
      if (typeof acode.addIcon !== "function") return
      var svg =
        '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">' +
        '<rect width="24" height="24" rx="5" fill="#0b1220"/>' +
        '<path d="M6.5 7.2 11.3 12l-4.8 4.8" fill="none" stroke="#67e8f9" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/>' +
        '<path d="M13 16.8h5" fill="none" stroke="#67e8f9" stroke-width="2.2" stroke-linecap="round"/>' +
        "</svg>"
      acode.addIcon(ICON_CLASS, "data:image/svg+xml;charset=utf-8," + encodeURIComponent(svg))
    } catch (error) {
      // The icon is optional.
    }
  }

  OpencodePlugin.prototype.addCommand = function (descriptor) {
    try {
      if (this.commands && typeof this.commands.addCommand === "function") {
        this.commands.addCommand(descriptor)
      } else if (typeof acode.addCommand === "function") {
        acode.addCommand(descriptor)
      }
    } catch (error) {
      console.error("[opencode] failed to register command " + descriptor.name, error)
    }
  }

  OpencodePlugin.prototype.removeCommand = function (name) {
    try {
      if (this.commands && typeof this.commands.removeCommand === "function") {
        this.commands.removeCommand(name)
      } else if (typeof acode.removeCommand === "function") {
        acode.removeCommand(name)
      }
    } catch (error) {
      // Command may already be gone.
    }
  }

  OpencodePlugin.prototype.registerCommands = function () {
    var self = this
    this.addCommand({
      name: "opencode.launch",
      description: "opencode: Launch in a new terminal",
      exec: function () {
        self.launch("new")
        return true
      },
    })
    this.addCommand({
      name: "opencode.continue",
      description: "opencode: Continue the last session",
      exec: function () {
        self.launch("continue")
        return true
      },
    })
  }

  OpencodePlugin.prototype.registerServerCommands = function () {
    var self = this
    this.addCommand({
      name: "opencode.serve",
      description: "opencode: Start server (opencode serve)",
      exec: function () {
        self.serve()
        return true
      },
    })
    this.addCommand({
      name: "opencode.openServer",
      description: "opencode: Open server URL",
      exec: function () {
        self.showServerReady()
        return true
      },
    })
    this.addCommand({
      name: "opencode.stopServer",
      description: "opencode: Stop server",
      exec: function () {
        self.stopServer()
        return true
      },
    })
  }

  OpencodePlugin.prototype.registerSideButton = function () {
    var self = this
    try {
      var SideButton = acode.require("sideButton")
      if (typeof SideButton !== "function") return
      this.sideButton = SideButton({
        text: "opencode",
        icon: ICON_CLASS,
        backgroundColor: "#0b1220",
        textColor: "#67e8f9",
        onclick: function () {
          self.menu()
        },
      })
      if (this.sideButton && typeof this.sideButton.show === "function") {
        this.sideButton.show()
      }
    } catch (error) {
      this.sideButton = null
    }
  }

  OpencodePlugin.prototype.launch = async function (mode) {
    var terminal
    try {
      terminal = acode.require("terminal")
    } catch (error) {
      terminal = null
    }

    if (!terminal || typeof terminal.create !== "function") {
      notifyError(
        "opencode",
        "Acode's Terminal API is not available. Update Acode and install its terminal environment.",
      )
      return
    }

    var directory = String(readSetting("cwd") || DEFAULTS.cwd).trim() || DEFAULTS.cwd
    var command = launchCommand(mode)

    try {
      var term = await terminal.create({
        name: mode === "continue" ? "opencode (continue)" : "opencode",
        serverMode: true,
      })
      // Give the shell a moment to bind before injecting the command.
      await delay(500)
      terminal.write(term.id, command + "\r")
      toast("opencode launched in " + directory)
    } catch (error) {
      var reason = error && error.message ? error.message : String(error)
      notifyError("opencode", "Could not start the terminal: " + reason)
    }
  }


  OpencodePlugin.prototype.menu = async function () {
    var choice = await pick("opencode", [
      ["serve", "Start server (opencode serve)"],
      ["open", "Open server URL"],
      ["stop", "Stop server"],
      ["new", "Launch in a new terminal"],
      ["continue", "Continue the last session"],
    ])
    if (choice === "serve") this.serve()
    else if (choice === "open") this.showServerReady()
    else if (choice === "stop") this.stopServer()
    else if (choice === "new" || choice === "continue") this.launch(choice)
  }

  // Tell the user where the server is and let them go there.
  OpencodePlugin.prototype.showServerReady = async function () {
    var url = serverUrl()
    var up = await probe(url, 1500)
    if (!up) {
      var start = await pick("opencode server is not running", [
        ["start", "Start it now"],
        ["close", "Close"],
      ])
      if (start === "start") this.serve()
      return
    }
    try {
      if (typeof acode.pushNotification === "function") {
        acode.pushNotification("opencode server is running", "Go to " + url, { type: "success" })
      }
    } catch (error) {
      // optional
    }
    var choice = await pick("opencode server is ready. Go to " + url, [
      ["open", "Open " + url],
      ["copy", "Copy URL"],
      ["close", "Close"],
    ])
    if (choice === "open") {
      if (!openExternal(url)) toast("Open " + url + " in your browser")
    } else if (choice === "copy") {
      toast(copyText(url) ? "Copied " + url : "Open " + url + " in your browser")
    }
  }

  OpencodePlugin.prototype.serve = async function () {
    var url = serverUrl()

    // Already up (maybe from an earlier launch): just point the user at it.
    if (await probe(url, 1200)) {
      toast("opencode server is already running")
      this.showServerReady()
      return
    }

    var terminal
    try {
      terminal = acode.require("terminal")
    } catch (error) {
      terminal = null
    }
    if (!terminal || typeof terminal.create !== "function") {
      notifyError(
        "opencode",
        "Acode's Terminal API is not available. Update Acode and install its terminal environment.",
      )
      return
    }

    var run = ++this.serveRun
    try {
      var term = await terminal.create({ name: "opencode server", serverMode: true })
      this.serverTermId = term.id
      await delay(500)
      terminal.write(term.id, serveCommand() + "\r")
    } catch (error) {
      var reason = error && error.message ? error.message : String(error)
      notifyError("opencode", "Could not start the terminal: " + reason)
      return
    }

    toast("Starting opencode server. Go to " + url + " when it is ready.", 4000)

    // Poll until it answers (first run may take a while if npm has to fetch it).
    var deadline = Date.now() + 120000
    while (Date.now() < deadline) {
      await delay(1000)
      if (run !== this.serveRun) return // stopped or restarted
      if (await probe(url, 1200)) {
        this.showServerReady()
        return
      }
    }
    notifyError(
      "opencode",
      "The server did not answer at " + url + " after 2 minutes. Check the 'opencode server' terminal tab for errors.",
    )
  }

  OpencodePlugin.prototype.stopServer = function () {
    this.serveRun++
    var stopped = false
    try {
      var terminal = acode.require("terminal")
      if (terminal && this.serverTermId !== null && typeof terminal.write === "function") {
        terminal.write(this.serverTermId, "\x03")
        stopped = true
      }
    } catch (error) {
      stopped = false
    }
    this.serverTermId = null
    toast(stopped ? "Stopping opencode server" : "Close the 'opencode server' terminal tab to stop it")
  }

  OpencodePlugin.prototype.destroy = function () {
    this.removeCommand("opencode.launch")
    this.removeCommand("opencode.continue")
    this.removeCommand("opencode.serve")
    this.removeCommand("opencode.openServer")
    this.removeCommand("opencode.stopServer")
    this.serveRun++
    if (this.sideButton && typeof this.sideButton.hide === "function") {
      try {
        this.sideButton.hide()
      } catch (error) {
        // Ignore teardown errors.
      }
    }
    this.sideButton = null
    this.commands = null
  }

  if (window.acode) {
    var plugin = new OpencodePlugin()

    acode.setPluginInit(
      PLUGIN_ID,
      async function (baseUrl, $page, options) {
        plugin.baseUrl = baseUrl ? (baseUrl.endsWith("/") ? baseUrl : baseUrl + "/") : ""
        await plugin.init($page, options || {})
      },
      {
        list: [
          {
            key: "command",
            text: "opencode command",
            info: "Command used to start opencode inside Acode's Alpine terminal.",
            prompt: "Command",
            value: readSetting("command"),
          },
          {
            key: "cwd",
            text: "Working directory",
            info: "Directory to enter before launching. Use ~ for the terminal home.",
            prompt: "Directory",
            value: readSetting("cwd"),
          },
          {
            key: "args",
            text: "Extra arguments",
            info: "Appended to the command, for example --model opencode/big-pickle.",
            prompt: "Arguments",
            value: readSetting("args"),
          },
          {
            key: "port",
            text: "Server port",
            info: "Port for opencode serve. The URL shown to you is built from this.",
            prompt: "Port",
            value: readSetting("port"),
          },
          {
            key: "host",
            text: "Server host",
            info: "Address for opencode serve to bind. Use 127.0.0.1 to keep it on this phone.",
            prompt: "Host",
            value: readSetting("host"),
          },
          {
            key: "serveArgs",
            text: "Server extra arguments",
            info: "Appended to opencode serve.",
            prompt: "Arguments",
            value: readSetting("serveArgs"),
          },
        ],
        cb: function (key, value) {
          writeSetting(key, value)
        },
      },
    )

    acode.setPluginUnmount(PLUGIN_ID, function () {
      plugin.destroy()
    })
  }
})()
