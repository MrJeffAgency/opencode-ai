# opencode for Acode

Launch [opencode](https://opencode.ai) inside Acode's Alpine terminal and jump
between opencode and the editor.

Owner: [MrJeffAgency](https://github.com/MrJeffAgency)

## Features

- **opencode: Launch in a new terminal** command.
- **opencode: Continue the last session** command (`--continue`).
- **opencode: Start server (opencode serve)** command. It starts the server in a terminal tab, waits until it answers, then tells you to go to the server URL (default `http://127.0.0.1:4096`) with **Open** and **Copy URL** buttons.
- **opencode: Open server URL** and **opencode: Stop server** commands.
- A tappable **opencode** side button that opens a menu of all actions.
- Configurable command, working directory, and extra arguments.

## Usage

1. Install the plugin.
2. Open the command palette and run **opencode: Launch in a new terminal**, or
   tap the **opencode** side button.
3. A terminal tab opens, enters the configured directory, and starts opencode.

### Server mode

1. Run **opencode: Start server (opencode serve)** from the command palette or the side button menu.
2. A terminal tab named "opencode server" opens and prints the URL.
3. When the server answers, a prompt says "Go to http://127.0.0.1:4096". Tap **Open** to go there.

If the server is already running, the plugin skips starting it and just shows the prompt.

The companion opencode plugin opens edited files back in Acode automatically.

## Settings

Open **Settings -> Plugins -> opencode**:

- **opencode command** - defaults to `opencode`.
- **Working directory** - a path inside Acode's Alpine terminal. Defaults to
  `~`, the terminal home.
- **Server port / Server host** - default `4096` and `127.0.0.1`.
- **Server extra arguments** - appended to `opencode serve`.
- **Extra arguments** - appended to the command, for example
  `--model opencode/big-pickle`.

## Requirements

- Acode with the Terminal API and the Alpine terminal environment installed.
- `opencode` installed and available on `PATH` inside the terminal.
- Acode version code 954 or newer.

## Notes

Acode's editor paths (`/storage/emulated/0/...`) and the Alpine sandbox paths
are different namespaces. Set the working directory to the sandbox path where
your project lives; `~` (usually `/public`) is a safe starting point.
