(() => {
const ID = 'mrjeffagency.aiagentpro';
const DEFAULT_CHAT_API = 'https://luckyai-blush.vercel.app/api/chat?message=';
const PRESETS = [
 ['OpenAI','openai','https://api.openai.com/v1','gpt-4o'],
 ['Anthropic','anthropic','https://api.anthropic.com/v1','claude-sonnet-4-5'],
 ['Groq','openai','https://api.groq.com/openai/v1','llama-3.3-70b-versatile'],
 ['DeepSeek','openai','https://api.deepseek.com/v1','deepseek-chat'],
 ['Google Gemini','openai','https://generativelanguage.googleapis.com/v1beta/openai','gemini-2.0-flash'],
 ['MiniMax','openai','https://api.minimax.io/v1','MiniMax-M2'],
 ['Mistral','openai','https://api.mistral.ai/v1','mistral-large-latest'],
 ['xAI (Grok)','openai','https://api.x.ai/v1','grok-4'],
 ['OpenRouter','openai','https://openrouter.ai/api/v1','openai/gpt-4o'],
 ['Together AI','openai','https://api.together.xyz/v1','meta-llama/Llama-3.3-70B-Instruct-Turbo'],
 ['Fireworks AI','openai','https://api.fireworks.ai/inference/v1','accounts/fireworks/models/llama-v3p3-70b-instruct'],
 ['Perplexity','openai','https://api.perplexity.ai','sonar'],
 ['Cerebras','openai','https://api.cerebras.ai/v1','llama3.1-8b'],
 ['NVIDIA NIM','openai','https://integrate.api.nvidia.com/v1','meta/llama-3.3-70b-instruct'],
 ['Ollama (local)','openai','http://127.0.0.1:11434/v1','llama3.2'],
 ['LM Studio (local)','openai','http://127.0.0.1:1234/v1','local-model'],
];
const K = { cfg:'aiagentpro.cfg', chats:'aiagentpro.chats', root:'aiagentpro.root', rootName:'aiagentpro.rootName' };
const load = (k, d) => { try { return JSON.parse(localStorage.getItem(k)) ?? d; } catch { return d; } };
const save = (k, v) => localStorage.setItem(k, JSON.stringify(v));
const esc = s => String(s).replace(/[&<>]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;'}[c]));
const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 6);

const SYSTEM = `You are an AI coding agent inside the Acode editor, scoped to one project folder.
To act, output tool calls as fenced blocks exactly like:
\`\`\`tool
{"tool":"read_file","path":"src/app.js"}
\`\`\`
Tools:
- list_files {"path":"."}  (lists a folder, 2 levels deep)
- read_file {"path":"..."}
- write_file {"path":"...","content":"full new content"}
- edit_file {"path":"...","start_line":N,"end_line":M,"content":"replacement lines"} (1-based inclusive; replaces those lines; for pure insert use end_line = start_line-1)
- create_file {"path":"...","content":"..."} (missing folders are created)
- delete_file {"path":"..."}
- web_search {"query":"..."} (only if enabled)
- mcp_call {"server":"name","tool":"toolName","arguments":{}} (only if MCP servers are configured)
Paths are relative to the project root, never use "..". read_file/list_files/web_search/mcp_call results come back automatically; continue in the same turn. Prefer edit_file for small changes in existing files. Read a file before editing it. Be concise; explain briefly what you do.`;

function lineDiff(a, b) {
  const A = a.split('\n'), B = b.split('\n');
  if (A.length * B.length > 4e6) return [['-', '(file too large for diff: ' + A.length + ' lines before, ' + B.length + ' after)']];
  const n = A.length, m = B.length, L = Array.from({length:n+1}, () => new Uint16Array(m+1));
  for (let i=n-1;i>=0;i--) for (let j=m-1;j>=0;j--) L[i][j] = A[i]===B[j] ? L[i+1][j+1]+1 : Math.max(L[i+1][j], L[i][j+1]);
  const out = []; let i=0, j=0;
  while (i<n && j<m) { if (A[i]===B[j]) { out.push([' ',A[i]]); i++; j++; } else if (L[i+1][j] >= L[i][j+1]) out.push(['-',A[i++]]); else out.push(['+',B[j++]]); }
  while (i<n) out.push(['-',A[i++]]); while (j<m) out.push(['+',B[j++]]);
  return out;
}

acode.setPluginInit(ID, async (baseUrl, $page) => {
  const fsOp = acode.require('fsOperation');
  const toast = acode.require('toast');
  function Page(title) {
    const o = document.createElement('div');
    o.style.cssText = 'position:fixed;inset:0;z-index:9000;background:#0d1117;color:#e6edf3;display:flex;flex-direction:column;padding-top:env(safe-area-inset-top,0px)';
    const h = document.createElement('div');
    h.style.cssText = 'display:flex;align-items:center;gap:8px;padding:8px 10px;border-bottom:1px solid #30363d;background:#161b22;color:#e6edf3';
    h.innerHTML = '<button style="font-size:18px;background:none;border:none;color:inherit">←</button><b style="flex:1"></b>';
    h.querySelector('b').textContent = title;
    const c = document.createElement('div'); c.style.cssText = 'position:relative;flex:1;min-height:0';
    o.append(h, c);
    const api = { onhide: null, show() { document.body.append(o); }, hide() { if (o.isConnected) { o.remove(); api.onhide && api.onhide(); } }, set body(el) { c.innerHTML = ''; c.append(el); } };
    h.querySelector('button').onclick = () => api.hide();
    return api;
  }
  const confirmBox = acode.require('confirm');
  const select = acode.require('select');
  const prompt = acode.require('prompt');

  const style = document.createElement('style');
  style.textContent = `
  .aap{--primary-color:#0d1117;--primary-text-color:#e6edf3;--secondary-color:#161b22;--secondary-text-color:#e6edf3;--border-color:#30363d;--button-background-color:#0969da;--button-text-color:#fff;display:flex;flex-direction:column;position:absolute;inset:0;background:#0d1117;color:#e6edf3;font-size:14px}
  .aap .bar{display:flex;gap:6px;align-items:center;padding:6px;border-bottom:1px solid var(--border-color)}
  .aap .bar b{flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  .aap button{background:var(--secondary-color);color:var(--secondary-text-color);border:1px solid var(--border-color);border-radius:6px;padding:6px 10px;font-size:13px}
  .aap button.pri{background:var(--button-background-color);color:var(--button-text-color)}
  .aap button.dng{background:#b3261e;color:#fff}
  .aap .msgs{flex:1;overflow:auto;padding:8px;user-select:text;background:#0d1117}
  .aap .bar,.aap .in{background:#161b22}
  .aap .a{background:#1c2128;color:#e6edf3}
  .aap .u{background:#12395c;color:#fff}
  .aap .m{margin:6px 0;padding:8px 10px;border-radius:10px;white-space:pre-wrap;word-break:break-word;max-width:96%}
  .aap .u{background:var(--button-background-color);color:var(--button-text-color);margin-left:auto}
  .aap .a{background:var(--secondary-color);color:var(--secondary-text-color)}
  .aap .s{font-size:12px;opacity:.75;background:transparent;border:1px dashed var(--border-color)}
  .aap pre{background:rgba(0,0,0,.25);padding:6px;border-radius:6px;overflow:auto;max-height:260px;margin:4px 0;font-size:12px}
  .aap .card{border:1px solid var(--border-color);border-radius:8px;padding:8px;margin:6px 0}
  .aap .card .row{display:flex;gap:6px;flex-wrap:wrap;margin-top:6px}
  .aap .add{color:#3fb950}.aap .del{color:#f85149}
  .aap .in{display:flex;gap:6px;padding:6px;border-top:1px solid var(--border-color)}
  .aap textarea{flex:1;min-height:44px;max-height:120px;background:var(--secondary-color);color:var(--secondary-text-color);border:1px solid var(--border-color);border-radius:8px;padding:6px}
  .aap input,.aap select{width:100%;box-sizing:border-box;background:var(--secondary-color);color:var(--secondary-text-color);border:1px solid var(--border-color);border-radius:6px;padding:8px;margin:3px 0 8px}
  .aap .pad{padding:12px;overflow:auto;flex:1}
  .aap .item{padding:10px;border-bottom:1px solid var(--border-color)}
  `;
  style.textContent += `.icon.aiagent-icon{background:url(${baseUrl}icon.png) center/contain no-repeat !important;width:28px;height:28px}
  .aiagent-side{padding:12px}.aiagent-side button{width:100%;padding:10px;margin-top:8px;border-radius:6px;border:1px solid var(--border-color);background:var(--button-background-color);color:var(--button-text-color)}.aiagent-side .aa-actions{display:flex;gap:8px}.aiagent-side .aa-actions button{flex:1}`;
  document.head.append(style);

  const savedCfg = load(K.cfg, {});
  let cfg = Object.assign({ type:'query', endpoint:DEFAULT_CHAT_API, key:'', model:'', auto:false, web:false, mcp:[] }, savedCfg);
  // Move saved Zen settings to the requested chat URL and clear their old key.
  if (!savedCfg.endpoint || /\/zen\/v1(?:\/|$)/i.test(savedCfg.endpoint) || savedCfg.model === 'big-pickle') {
    cfg.type = 'query'; cfg.endpoint = DEFAULT_CHAT_API; cfg.key = ''; cfg.model = '';
    save(K.cfg, cfg);
  }
  let rootUrl = load(K.root, '');
  let rootName = load(K.rootName, '');
  let chats = load(K.chats, []);
  let chat = null, busy = false, ui = null, abortCtl = null;

  const newChat = () => { chat = { id: uid(), title: 'New chat', ts: Date.now(), msgs: [] }; };
  const persist = () => { if (!chat.msgs.length) return; chats = chats.filter(c => c.id !== chat.id); chats.unshift(chat); save(K.chats, chats.slice(0, 200)); };
  newChat();

  // ---------- file helpers (all locked to root) ----------
  const clean = p => {
    p = String(p || '.').replace(/\\/g, '/').replace(/^\/+/, '');
    const parts = p.split('/').filter(x => x && x !== '.');
    if (parts.includes('..')) throw new Error('Path escapes project root: ' + p);
    return parts;
  };
  const urlOf = parts => rootUrl.replace(/\/+$/, '') + (parts.length ? '/' + parts.map(encodeURIComponent).join('/') : '');
  const needRoot = () => { if (!rootUrl) throw new Error('No project folder selected. Tap 📂 Folder, or add one in Acode Files → Add folder.'); };
  const exists = async u => { try { return await fsOp(u).exists(); } catch { return false; } };
  const readText = async parts => { needRoot(); return await fsOp(urlOf(parts)).readFile('utf-8'); };
  async function ensureDirs(parts) {
    let cur = [];
    for (const seg of parts) {
      const parent = urlOf(cur); cur = [...cur, seg];
      if (!(await exists(urlOf(cur)))) await fsOp(parent).createDirectory(seg);
    }
  }
  async function writeText(parts, content, create) {
    needRoot();
    const dir = parts.slice(0, -1), name = parts[parts.length - 1];
    await ensureDirs(dir);
    const u = urlOf(parts);
    if (await exists(u)) await fsOp(u).writeFile(content);
    else await fsOp(urlOf(dir)).createFile(name, content);
  }
  async function listDir(parts, depth) {
    needRoot();
    const items = await fsOp(urlOf(parts)).lsDir(); let out = [];
    for (const it of items.sort((a,b)=>a.name.localeCompare(b.name))) {
      if (['node_modules','.git'].includes(it.name)) continue;
      const rel = [...parts, it.name];
      out.push(rel.join('/') + (it.isDirectory ? '/' : ''));
      if (it.isDirectory && depth > 1) out = out.concat(await listDir(rel, depth - 1));
    }
    return out;
  }

  // ---------- AI call ----------
  const base = () => cfg.endpoint.replace(/\/+$/, '');
  const messageUrl = (endpoint, message) => {
    const encoded = encodeURIComponent(message);
    if (endpoint.includes('{message}')) return endpoint.replaceAll('{message}', encoded);
    const u = new URL(endpoint);
    u.searchParams.set('message', message);
    return u.toString();
  };
  async function callAI(msgs) {
    if (!cfg.endpoint || (cfg.type !== 'query' && !cfg.model)) throw new Error('Open Settings and set the endpoint' + (cfg.type === 'query' ? '.' : ' and model.'));
    let sys = SYSTEM;
    if (!cfg.web) sys += '\nweb_search is disabled.';
    if (!cfg.mcp.length) sys += '\nNo MCP servers configured.'; else sys += '\nMCP servers: ' + cfg.mcp.map(s => s.name).join(', ');
    sys += '\nProject root listing (2 levels):\n' + (rootUrl ? (await listDir([], 2).catch(() => [])).slice(0, 200).join('\n') : '(no folder selected)');
    abortCtl = new AbortController();
    if (cfg.type === 'query') {
      const transcript = msgs.map(m => (m.role === 'assistant' ? 'Assistant' : 'User') + ':\n' + m.content).join('\n\n');
      const promptText = sys + '\n\nConversation so far:\n' + transcript + '\n\nAssistant:';
      const r = await fetch(messageUrl(cfg.endpoint.trim(), promptText), { method:'GET', signal:abortCtl.signal });
      const raw = await r.text();
      let j = null; try { j = JSON.parse(raw); } catch {}
      if (!r.ok) {
        const err = j?.error?.message || j?.error || j?.message || raw || ('HTTP ' + r.status);
        throw new Error(String(err).slice(0, 500));
      }
      const answer = typeof j === 'string' ? j : (j?.response ?? j?.answer ?? j?.output_text ?? j?.output ?? j?.text ?? j?.content);
      if (answer == null) return raw || '(The API returned an empty response.)';
      if (Array.isArray(answer)) return answer.map(x => typeof x === 'string' ? x : (x.text || '')).join('\n');
      if (typeof answer === 'object') return answer.text || answer.content || JSON.stringify(answer);
      return String(answer);
    }
    const body = cfg.type === 'anthropic'
      ? { model: cfg.model, max_tokens: 8192, system: sys, messages: msgs }
      : { model: cfg.model, messages: [{ role:'system', content: sys }, ...msgs] };
    const headers = { 'Content-Type':'application/json' };
    if (cfg.type === 'anthropic') { headers['x-api-key'] = cfg.key; headers['anthropic-version'] = '2023-06-01'; headers['anthropic-dangerous-direct-browser-access'] = 'true'; }
    else if (cfg.key) headers['Authorization'] = 'Bearer ' + cfg.key;
    const r = await fetch(base() + (cfg.type === 'anthropic' ? '/messages' : '/chat/completions'), { method:'POST', headers, body: JSON.stringify(body), signal: abortCtl.signal });
    const j = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error((j.error && (j.error.message || j.error)) || ('HTTP ' + r.status));
    return cfg.type === 'anthropic' ? (j.content || []).map(c => c.text || '').join('') : (j.choices?.[0]?.message?.content || '');
  }

  async function webSearch(q) {
    const r = await fetch('https://api.duckduckgo.com/?format=json&no_html=1&skip_disambig=1&q=' + encodeURIComponent(q));
    const j = await r.json();
    const rel = (j.RelatedTopics || []).flatMap(t => t.Topics || [t]).slice(0, 6).map(t => '- ' + t.Text + (t.FirstURL ? ' (' + t.FirstURL + ')' : ''));
    return [j.Heading, j.AbstractText, ...rel].filter(Boolean).join('\n') || 'No instant-answer results.';
  }
  async function mcpCall(a) {
    const s = cfg.mcp.find(x => x.name === a.server); if (!s) throw new Error('Unknown MCP server: ' + a.server);
    const r = await fetch(s.url, { method:'POST', headers: Object.assign({ 'Content-Type':'application/json', 'Accept':'application/json, text/event-stream' }, s.token ? { Authorization:'Bearer ' + s.token } : {}), body: JSON.stringify({ jsonrpc:'2.0', id: 1, method:'tools/call', params:{ name:a.tool, arguments:a.arguments || {} } }) });
    const t = await r.text();
    return t.slice(0, 8000);
  }

  // ---------- parsing ----------
  function parseTools(text) {
    const calls = []; const re = /```tool\s*([\s\S]*?)```/g; let m;
    while ((m = re.exec(text))) { try { calls.push(JSON.parse(m[1])); } catch { calls.push({ tool:'_bad', raw:m[1] }); } }
    return calls;
  }
  const strip = t => t.replace(/```tool[\s\S]*?```/g, '').trim();

  // ---------- chat UI ----------
  const addMsg = (cls, html) => { const d = document.createElement('div'); d.className = 'm ' + cls; d.innerHTML = html; ui.msgs.append(d); ui.msgs.scrollTop = 1e9; return d; };
  const note = t => addMsg('s', esc(t));

  function showModal(title, html) {
    const o = document.createElement('div');
    o.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,.7);z-index:9999;display:flex;flex-direction:column;padding:10px';
    o.innerHTML = `<div class="aap" style="position:relative;flex:1;border-radius:10px;overflow:hidden"><div class="bar"><b>${esc(title)}</b><button>Close</button></div><div class="msgs">${html}</div></div>`;
    o.querySelector('button').onclick = () => o.remove();
    document.body.append(o);
  }
  function diffHtml(oldT, newT) {
    return '<pre>' + lineDiff(oldT, newT).filter((l, i, a) => l[0] !== ' ' || a.slice(Math.max(0,i-2), i+3).some(x => x[0] !== ' ')).map(([k, t]) => `<div class="${k==='+'?'add':k==='-'?'del':''}">${k} ${esc(t)}</div>`).join('') + '</pre>';
  }

  async function proposeAction(a) {
    const parts = clean(a.path); const label = a.tool + ' ' + parts.join('/');
    const card = document.createElement('div'); card.className = 'card';
    let newText, oldText = null, isNew = false;
    const u = urlOf(parts); const ex = await exists(u);
    if (a.tool === 'delete_file') { newText = null; }
    else if (a.tool === 'edit_file') {
      oldText = await readText(parts); const L = oldText.split('\n');
      const s = Math.max(1, +a.start_line), e = Math.min(L.length, +a.end_line);
      L.splice(s - 1, Math.max(0, e - s + 1), ...String(a.content ?? '').split('\n')); newText = L.join('\n');
    } else { newText = String(a.content ?? ''); isNew = !ex; if (ex) oldText = await readText(parts); }
    card.innerHTML = `<b>${esc(label)}</b><div class="row"></div>`;
    const row = card.querySelector('.row');
    const btn = (t, cls, fn) => { const b = document.createElement('button'); b.textContent = t; if (cls) b.className = cls; b.onclick = fn; row.append(b); return b; };
    const apply = async () => {
      try {
        if (a.tool === 'delete_file') await fsOp(u).delete(); else await writeText(parts, newText);
        card.innerHTML = '<b>✔ Applied:</b> ' + esc(label);
        chat.msgs.push({ role:'user', content:'[system] Applied ' + label }); persist();
      } catch (e) { toast('Failed: ' + e.message, 3000); }
    };
    if (a.tool === 'delete_file') {
      btn('Confirm delete', 'dng', async () => { if (await confirmBox('Delete', 'Delete ' + parts.join('/') + '?')) apply(); });
    } else {
      btn(isNew ? 'View new file' : 'View diff', '', () => showModal(label, isNew ? '<pre>' + esc(newText) + '</pre>' : diffHtml(oldText, newText)));
      btn('Apply', 'pri', apply);
      if (cfg.auto) apply();
    }
    btn('Dismiss', '', () => card.remove());
    ui.msgs.append(card); ui.msgs.scrollTop = 1e9;
  }

  async function runTool(a) {
    switch (a.tool) {
      case 'list_files': return (await listDir(clean(a.path), 2)).join('\n') || '(empty)';
      case 'read_file': { const t = await readText(clean(a.path)); return t.length > 60000 ? t.slice(0, 60000) + '\n...[truncated]' : t; }
      case 'web_search': if (!cfg.web) throw new Error('web search disabled'); return await webSearch(a.query);
      case 'mcp_call': return await mcpCall(a);
      default: throw new Error('unknown tool ' + a.tool);
    }
  }

  async function send(text) {
    if (busy || !text.trim()) return;
    busy = true; ui.sendBtn.textContent = 'Stop';
    chat.msgs.push({ role:'user', content: text }); if (chat.title === 'New chat') chat.title = text.slice(0, 50);
    addMsg('u', esc(text));
    try {
      for (let round = 0; round < 7; round++) {
        const wait = addMsg('s', 'Thinking…');
        let reply; try { reply = await callAI(chat.msgs.map(m => ({ role: m.role, content: m.content }))); } finally { wait.remove(); }
        chat.msgs.push({ role:'assistant', content: reply });
        const say = strip(reply); if (say) addMsg('a', esc(say));
        const calls = parseTools(reply); if (!calls.length) break;
        if (round === 6) { note('Agent loop limit (6 rounds) reached.'); break; }
        let results = [], more = false;
        for (const c of calls) {
          try {
            if (c.tool === '_bad') { results.push('Invalid tool JSON: ' + c.raw.slice(0, 200)); more = true; }
            else if (['write_file','edit_file','create_file','delete_file'].includes(c.tool)) await proposeAction(c);
            else { note('→ ' + c.tool + ' ' + (c.path || c.query || c.tool)); results.push('[' + c.tool + ' result]\n' + await runTool(c)); more = true; }
          } catch (e) { results.push('[' + c.tool + ' error] ' + e.message); more = true; }
        }
        if (!more) break;
        chat.msgs.push({ role:'user', content: results.join('\n\n') });
      }
    } catch (e) { if (e.name !== 'AbortError') note('Error: ' + e.message); }
    busy = false; ui.sendBtn.textContent = 'Send'; persist();
  }

  // ---------- screens ----------
  async function pickFolder() {
    try {
      const browseFolder = acode.require('fileBrowser');
      if (typeof browseFolder !== 'function') throw new Error('Acode folder browser is unavailable. Update Acode and try again.');
      // Start at the browser home rather than inside the previously selected project.
      const result = await browseFolder('folder', 'Choose the project folder for AI Agent', false);
      if (!result || result.type !== 'folder' || !result.url) return;
      rootUrl = result.url; rootName = result.name || 'Project folder';
      save(K.root, rootUrl); save(K.rootName, rootName);
      if (ui?.folder) ui.folder.textContent = '📂 ' + rootName;
      toast('Project folder selected: ' + rootName, 2500);
    } catch (e) {
      if (/cancel|dismiss/i.test(String(e?.message || e))) return;
      toast('Could not select folder: ' + (e.message || e), 4000);
    }
  }

  function settingsScreen() {
    const p = Page('AI Agent settings'); const d = document.createElement('div'); d.className = 'aap';
    d.innerHTML = `<div class="pad">
    <label>Quick preset</label><select id="pre"><option value="">Custom / other</option>${PRESETS.map((p,i)=>`<option value="${i}">${p[0]}</option>`).join('')}</select>
    <label>API type</label><select id="type"><option value="query">Chat URL (GET with message parameter)</option><option value="openai">OpenAI-compatible</option><option value="anthropic">Anthropic</option></select>
    <label>Endpoint URL</label><input id="ep" placeholder="https://example.com/api/chat?message=">
    <div id="queryHelp" style="font-size:12px;opacity:.75;margin:-4px 0 8px">This chat API receives a GET request with your conversation in the message parameter. No API key or model name is needed.</div>
    <div id="keyWrap"><label>API key</label><input id="key" type="password"></div>
    <div id="modelWrap"><label>Model</label><input id="model" list="ml"><datalist id="ml"></datalist></div>
    <div style="display:flex;gap:8px"><button id="test" style="flex:1">Test API</button><button id="fetch" style="flex:1">Load models</button></div>
    <div id="status" role="status" style="padding:6px 0;opacity:.8"></div>
    <label style="display:block;margin-top:12px"><input id="auto" type="checkbox" style="width:auto"> Auto-apply writes/creates (deletes always ask)</label>
    <label style="display:block"><input id="web" type="checkbox" style="width:auto"> Web search (DuckDuckGo)</label>
    <label style="display:block;margin-top:10px">MCP servers (one per line: name|https://url|optional token)</label>
    <textarea id="mcp" style="width:100%;box-sizing:border-box;min-height:70px"></textarea>
    </div><div class="in"><button class="pri" id="save" style="flex:1;padding:12px">Save</button></div>`;
    const $ = s => d.querySelector(s);
    $('#type').value = cfg.type; $('#ep').value = cfg.endpoint; $('#key').value = cfg.key; $('#model').value = cfg.model;
    const updateTypeHelp = () => { const q = $('#type').value === 'query'; $('#keyWrap').style.display = q ? 'none' : ''; $('#modelWrap').style.display = q ? 'none' : ''; $('#fetch').style.display = q ? 'none' : ''; $('#queryHelp').style.display = q ? '' : 'none'; $('#test').textContent = q ? 'Test API' : 'Test server'; };
    updateTypeHelp();
    $('#type').onchange = updateTypeHelp;
    $('#auto').checked = cfg.auto; $('#web').checked = cfg.web; $('#mcp').value = cfg.mcp.map(s => [s.name, s.url, s.token || ''].join('|')).join('\n');
    $('#pre').onchange = e => { const x = PRESETS[e.target.value]; if (x) { $('#type').value = x[1]; $('#ep').value = x[2]; $('#model').value = x[3]; updateTypeHelp(); } };
    $('#test').onclick = async () => {
      const type = $('#type').value, ep = $('#ep').value.trim().replace(/\/+$/, ''), key = $('#key').value.trim();
      const status = $('#status'), button = $('#test');
      if (!ep) { status.textContent = 'Enter an endpoint URL first.'; return; }
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), 20000);
      button.disabled = true; status.textContent = 'Checking ' + ep + ' …';
      try {
        if (type === 'query') {
          const response = await fetch(messageUrl(ep, 'Reply with the word OK'), { method:'GET', signal:controller.signal });
          const raw = await response.text();
          let j = null; try { j = JSON.parse(raw); } catch {}
          if (!response.ok) status.textContent = 'API responded with HTTP ' + response.status + ': ' + String(j?.error || j?.message || raw).slice(0, 180);
          else status.textContent = 'Chat API reachable' + (j?.response ? ': ' + String(j.response).slice(0, 120) : '.');
        } else {
          const headers = type === 'anthropic'
            ? { 'x-api-key': key, 'anthropic-version':'2023-06-01', 'anthropic-dangerous-direct-browser-access':'true' }
            : (key ? { Authorization:'Bearer ' + key } : {});
          const response = await fetch(ep + '/models', { headers, signal:controller.signal });
          const detail = await response.text().catch(() => '');
          if (response.ok) status.textContent = 'Server reachable; /models responded successfully.';
          else if (response.status === 404 || response.status === 405) status.textContent = 'Server reachable, but /models is not supported (HTTP ' + response.status + '). You can still try your model.';
          else status.textContent = 'Server responded with HTTP ' + response.status + (detail ? ': ' + detail.slice(0, 180) : '. Check the API key and endpoint.');
        }
      } catch (e) {
        status.textContent = e.name === 'AbortError'
          ? 'Request timed out. Check the server and network.'
          : 'Could not reach the API. Check the URL and CORS settings.';
      } finally { clearTimeout(timer); button.disabled = false; }
    };
    $('#fetch').onclick = async () => {
      if ($('#type').value === 'query') return toast('This chat URL does not provide a model list.', 3000);
      try {
        const type = $('#type').value, ep = $('#ep').value.replace(/\/+$/, ''), key = $('#key').value;
        const h = type === 'anthropic' ? { 'x-api-key': key, 'anthropic-version':'2023-06-01', 'anthropic-dangerous-direct-browser-access':'true' } : (key ? { Authorization:'Bearer ' + key } : {});
        const j = await (await fetch(ep + '/models', { headers: h })).json();
        const ids = (j.data || j.models || []).map(m => m.id || m.name).filter(Boolean);
        $('#ml').innerHTML = ids.map(i => `<option value="${esc(i)}">`).join(''); toast(ids.length + ' models loaded');
      } catch (e) { $('#ml').innerHTML = (PRESETS.find(p => p[2] === $('#ep').value.replace(/\/+$/, '')) ? `<option value="${PRESETS.find(p => p[2] === $('#ep').value.replace(/\/+$/, ''))[3]}">` : ''); toast('Live fetch failed, using fallback', 3000); }
    };
    const collect = () => {
      cfg = { type: $('#type').value, endpoint: $('#ep').value.trim(), key: $('#key').value.trim(), model: $('#model').value.trim(), auto: $('#auto').checked, web: $('#web').checked,
        mcp: $('#mcp').value.split('\n').map(l => l.trim().split('|')).filter(a => a[0] && a[1]).map(a => ({ name:a[0], url:a[1], token:a[2] || '' })) };
      save(K.cfg, cfg);
    };
    d.addEventListener('input', collect); d.addEventListener('change', collect);
    p.onhide = collect;
    $('#save').onclick = () => { collect(); toast('Saved'); p.hide(); };
    p.body = d; p.show();
  }

  function historyScreen() {
    const p = Page('Chat history'); const d = document.createElement('div'); d.className = 'aap';
    d.innerHTML = '<div class="bar"><input id="q" placeholder="Search chats…" style="margin:0"></div><div class="msgs" id="list"></div>';
    const render = () => {
      const q = d.querySelector('#q').value.toLowerCase(); const list = d.querySelector('#list'); list.innerHTML = '';
      chats.filter(c => !q || c.title.toLowerCase().includes(q) || c.msgs.some(m => m.content.toLowerCase().includes(q))).forEach(c => {
        const it = document.createElement('div'); it.className = 'item';
        it.innerHTML = `<b>${esc(c.title)}</b><div style="opacity:.6;font-size:12px">${new Date(c.ts).toLocaleString()} · ${c.msgs.length} msgs</div><div class="row" style="display:flex;gap:6px;margin-top:6px"><button class="o">Open</button><button class="dng x">Delete</button></div>`;
        it.querySelector('.o').onclick = () => { persist(); chat = c; redraw(); p.hide(); };
        it.querySelector('.x').onclick = () => { chats = chats.filter(x => x.id !== c.id); save(K.chats, chats); if (chat.id === c.id) newChat(), redraw(); render(); };
        list.append(it);
      });
      if (!list.children.length) list.innerHTML = '<div class="item">No chats</div>';
    };
    d.querySelector('#q').oninput = render; render(); p.body = d; p.show();
  }

  function redraw() {
    ui.msgs.innerHTML = '';
    chat.msgs.forEach(m => { if (m.content.startsWith('[') && m.role === 'user') return note(m.content.slice(0, 120)); const t = m.role === 'assistant' ? strip(m.content) : m.content; if (t) addMsg(m.role === 'user' ? 'u' : 'a', esc(t)); });
  }

  function open() {
    const p = Page('AI Agent'); const d = document.createElement('div'); d.className = 'aap';
    d.innerHTML = `<div class="bar"><button id="fold" title="Choose project folder">📂 Folder</button><b id="fname"></b><button id="new">＋</button><button id="hist">🕘</button><button id="set">⚙️</button></div>
    <div class="msgs"></div><div class="in"><textarea placeholder="Ask the agent…"></textarea><button class="pri" id="send">Send</button></div>`;
    ui = { msgs: d.querySelector('.msgs'), sendBtn: d.querySelector('#send'), folder: d.querySelector('#fname') };
    ui.folder.textContent = rootUrl ? '📂 ' + (rootName || decodeURIComponent(rootUrl.split('/').filter(Boolean).pop() || 'Project')) : 'No folder selected';
    const ta = d.querySelector('textarea');
    d.querySelector('#fold').onclick = pickFolder;
    d.querySelector('#new').onclick = () => { persist(); newChat(); redraw(); };
    d.querySelector('#hist').onclick = historyScreen;
    d.querySelector('#set').onclick = settingsScreen;
    ui.sendBtn.onclick = () => { if (busy) { abortCtl && abortCtl.abort(); return; } const t = ta.value; ta.value = ''; send(t); };
    p.body = d; p.onhide = persist; p.show(); redraw();
  }

  const openAgent = () => { try { open(); } catch (e) { toast('AI Agent error: ' + e.message, 4000); } };
  const openSettings = () => { try { settingsScreen(); } catch (e) { toast('AI Agent settings error: ' + e.message, 4000); } };
  let commandRegistered = false;
  try {
    const editorCommands = window.editorManager?.editor?.commands;
    if (editorCommands?.addCommand) {
      editorCommands.addCommand({ name: 'ai-agent-pro', description: 'AI Agent', bindKey: null, exec: openAgent });
      commandRegistered = true;
    }
  } catch (e) { console.warn('AI Agent editor command unavailable', e); }
  if (!commandRegistered) {
    try { acode.require('commands')?.addCommand?.({ name: 'ai-agent-pro', description: 'AI Agent', exec: openAgent }); }
    catch (e) { console.warn('AI Agent command palette unavailable', e); }
  }
  try { acode.require('commands')?.addCommand?.({ name: 'ai-agent-settings', description: 'AI Agent Settings', exec: openSettings }); }
  catch (e) { console.warn('AI Agent settings command unavailable', e); }
  try {
    const sidebarApps = acode.require('sidebarApps');
    sidebarApps.add('aiagent-icon', 'aiagent-sidebar', 'AI Agent', el => {
      el.classList.add('aiagent-side');
      el.innerHTML = '<h3 style="margin:0">AI Agent</h3><p style="opacity:.7">Your AI coding agent.</p><div class="aa-actions"><button id="aa-open">Open AI Agent</button><button id="aa-settings">Settings</button></div><button id="aa-folder">📂 Choose project folder</button>';
      el.querySelector('#aa-open').onclick = () => { try { acode.require('sidebar')?.hide?.(); } catch {} try { open(); } catch (e) { toast('AI Agent error: ' + e.message, 4000); } };
      el.querySelector('#aa-settings').onclick = () => { try { acode.require('sidebar')?.hide?.(); } catch {} try { settingsScreen(); } catch (e) { toast('AI Agent settings error: ' + e.message, 4000); } };
      el.querySelector('#aa-folder').onclick = () => { try { acode.require('sidebar')?.hide?.(); } catch {} pickFolder(); };
    }, false, () => {});
  } catch (e) { console.warn('AI Agent sidebar icon unavailable', e); }
  window.__aap_unmount = () => { style.remove(); try { acode.require('sidebarApps').remove('aiagent-sidebar'); } catch {} };
});
acode.setPluginUnmount(ID, () => { try { window.__aap_unmount && window.__aap_unmount(); } catch {} });
})();
