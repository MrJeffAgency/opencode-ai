# AI Agent for Acode

**Version 1.2.1**

AI Agent adds a coding assistant to Acode. Select a project folder, ask questions about it, and let the agent inspect files or suggest changes. File writes and deletes are protected by previews and confirmation controls.

## Features

- Chat with an AI assistant from Acode’s sidebar or command palette.
- Choose a project folder with Acode’s folder browser. The assistant’s file tools stay limited to the selected folder.
- List files, read files, create files, edit files, and delete files. Review changes before applying them; deletes always ask for confirmation.
- Keep multiple chats in searchable history.
- Optionally enable DuckDuckGo web search and configure MCP servers.
- Use a dark interface that is independent of the device theme.

## Connect an AI provider

Open **AI Agent → Settings**. Choose an API type, enter the provider endpoint, API key, and model when required, then use **Test server** and **Load models** if the provider supports them. The plugin has a preconfigured chat URL mode for simple GET APIs that accept a `message` query parameter; that mode does not need a model name or API key. The endpoint itself can be changed in Settings.

### Included provider presets

The quick-preset list includes OpenAI, Anthropic, Groq, DeepSeek, Google Gemini, MiniMax, Mistral, xAI, OpenRouter, Together AI, Fireworks AI, Perplexity, Cerebras, NVIDIA NIM, Ollama, and LM Studio. Model availability, pricing, free quotas, and required account setup are controlled by each provider and can change. Check the provider’s current documentation and dashboard before use.

You can also select **Custom / other** and configure any service that supports the selected API type. OpenAI-compatible providers use a `/v1`-style base URL, bearer API key, and model ID. Anthropic-compatible providers use the Anthropic API type. Local Ollama or LM Studio endpoints must be reachable from the device running Acode. On Android, `127.0.0.1` refers to the phone or tablet itself.

## Select a project folder

Tap **📂 Folder** in the chat toolbar or **📂 Choose project folder** in the AI Agent sidebar. Browse to the directory you want and select it. Acode may ask for storage permission. If a storage location is not available in the browser, add it to Acode first using **Files → Add folder** or the File Browser’s **Add Connection** option.

## Privacy and safety

The selected project’s file names and relevant file contents may be sent to the configured AI provider when you ask the assistant to work with them. Avoid sending secrets unless you trust the provider. For simple GET chat APIs, the conversation is sent in the URL’s `message` query parameter, which may be recorded in server or network logs. API keys for standard provider modes are stored in the plugin’s local Acode settings and sent to the provider you configure.

AI-generated file changes should be reviewed before they are applied. Keep a backup or use version control for important projects.

## Install and update

In Acode, open **Settings → Plugins** or the Extensions sidebar, choose the local ZIP install option, and select this plugin archive. To update, install the newer ZIP and reload the plugin if Acode offers that option.

Author: MrJeffAgency (github.com/MrJeffAgency)
